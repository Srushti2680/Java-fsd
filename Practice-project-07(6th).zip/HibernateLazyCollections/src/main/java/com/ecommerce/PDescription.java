package com.ecommerce;

public class PDescription {
    private long id;
    private String descrip;

    public PDescription() {

    }

    public PDescription(String descrip) {
        this.id = 0;
        this.descrip = descrip;
    }

    public long getId() {
        return this.id;
    }

    public String getDescrip() {
        return this.descrip;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setDescrip(String descrip) {
        this.descrip = descrip;
    }
}
