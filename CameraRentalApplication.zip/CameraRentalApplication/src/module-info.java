/**
 * 
 */
/**
 * 
 */
module CameraRentalApplication {
}