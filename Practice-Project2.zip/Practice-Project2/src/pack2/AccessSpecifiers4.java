package pack2;

import pack1.PublicAccessSpecifiers;

public class AccessSpecifiers4 {
	public static void main(String[] args) {

		PublicAccessSpecifiers obj = new PublicAccessSpecifiers(); 
		obj.display();  

	}

}
