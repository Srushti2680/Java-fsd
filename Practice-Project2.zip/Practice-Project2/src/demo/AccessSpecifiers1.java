package demo;

public class AccessSpecifiers1 {
	public static void main(String[] args) {
		//default
		System.out.println("Dafault Access Specifier");
		DefAccessSpecifier obj = new DefAccessSpecifier(); 		  
		obj.display(); 

	}

}
