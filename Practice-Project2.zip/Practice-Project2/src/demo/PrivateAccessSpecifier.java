package demo;

class PrivateAccessSpecifier {
	   private void display() 
	    { 
	        System.out.println("You are using private access specifier"); 
	    } 

}
