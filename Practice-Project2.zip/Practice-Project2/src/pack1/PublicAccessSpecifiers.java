package pack1;

public class PublicAccessSpecifiers {
	public void display() 
	{ 
		System.out.println("This is Public Access Specifiers"); 
	} 

}
