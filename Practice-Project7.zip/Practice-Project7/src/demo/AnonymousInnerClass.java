package demo;

abstract class AnonymousInnerClass {
	public abstract void display();
}





