package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.connections.HiberConfig;
import com.ecommerce.EProduct;

@WebServlet("/ListProducts")
public class ListProducts extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            SessionFactory factory = HiberConfig.getSessionFactory();

            try (Session session = factory.openSession()) {
                // Using HQL
                Query<EProduct> query = session.createQuery("from EProduct", EProduct.class);
                List<EProduct> list = query.list();

                PrintWriter out = response.getWriter();
                out.println("<html><body>");
                out.println("<b>Product Listing</b><br>");
                out.println("<table border='1'>");
                out.println("<tr><th>ID</th><th>Name</th><th>Price</th><th>Date Added</th></tr>");

                for (EProduct p : list) {
                    out.println("<tr><td>" + p.getID() + "</td><td>" + p.getName() + "</td><td>" + p.getPrice()
                            + "</td><td>" + p.getDateAdded() + "</td></tr>");
                }

                out.println("</table>");
                out.println("</body></html>");
            }
        } catch (HibernateException ex) {
            ex.printStackTrace();
            throw new ServletException("Error retrieving products from the database.", ex);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
