package demo;

class EmpInfo {
	int id;
	String name;

void display() {
	System.out.println("Emp :"+id+" Name: "+name);
	}
}



