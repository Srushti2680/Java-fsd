package demo;

public class ParamConstrDemo {
	public static void main(String[] args) {

		Std std1=new Std(4,"Candy");
		Std std2=new Std(20,"Annie");
		std1.display();
		std2.display();
	}
}
